//
//  RecognIDiOSSDK.h
//  RecognIDiOSSDK
//
//  Created by Serhiy Vlasevych on 12/10/2022.
//  Copyright © 2022 MDFin Corporate Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for RecognIDiOSSDK.
FOUNDATION_EXPORT double RecognIDiOSSDKVersionNumber;

//! Project version string for RecognIDiOSSDK.
FOUNDATION_EXPORT const unsigned char RecognIDiOSSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RecognIDiOSSDK/PublicHeader.h>


